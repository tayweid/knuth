"""Serve the built app from the engine, on the engine's own port.

The page and the kernel socket share an origin, which is the whole point:
a secret never has to travel between them (see SAME_ORIGIN.md). This runs
inside the WebSocket server's `process_request` hook, so one port answers
both protocols and `websockets` remains the only runtime dependency.

The surface is deliberately read-only. A page from another origin can send
blind GETs here — it cannot read the responses, but it must never be able
to cause an effect with one either. Everything that executes code stays
behind the origin-checked WebSocket upgrade.
"""

import mimetypes
import posixpath
import urllib.parse
from pathlib import Path

from websockets.datastructures import Headers
from websockets.http11 import Response

# Populated by the release build (npm run build → knuth/web/). A source
# checkout without a build simply has no app to serve, and the engine still
# runs for `knuth run` and for a separately hosted frontend.
WEB_ROOT = Path(__file__).parent / "web"

INDEX = "index.html"

# The page's own meta policy has to admit the CDN that serves Pyodide, because
# the hosted preview runs Python in the tab. A locally served page never needs
# it — an engine is right here — so the engine sends the policy it actually
# wants as a header. Browsers enforce every policy they are given, so the
# stricter one wins and the local app cannot reach the network at all.
LOCAL_CSP = (
    "default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
    "font-src 'self'; img-src 'self' blob: data:; connect-src 'self' blob:; "
    "manifest-src 'self'; worker-src 'self' blob:; object-src 'none'; "
    "base-uri 'none'; form-action 'none'; frame-src 'none'"
)

# mimetypes' table varies by platform and misses the manifest entirely;
# a wrong type here makes the browser refuse to install the app.
CONTENT_TYPES = {
    ".css": "text/css; charset=utf-8",
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".otf": "font/otf",
    ".png": "image/png",
    ".svg": "image/svg+xml",
    ".ttf": "font/ttf",
    ".webmanifest": "application/manifest+json",
    ".woff": "font/woff",
    ".woff2": "font/woff2",
}


def available(root=None):
    """Whether this install carries a built frontend."""
    return (root or WEB_ROOT).joinpath(INDEX).is_file()


def _content_type(path):
    suffix = path.suffix.lower()
    if suffix in CONTENT_TYPES:
        return CONTENT_TYPES[suffix]
    guessed, _ = mimetypes.guess_type(path.name)
    return guessed or "application/octet-stream"


def _cache_control(relative):
    # Vite fingerprints everything under assets/, so those are immutable.
    # The shell must not be, or a pip upgrade would be invisible behind a
    # cached index — the service worker is network-first for the same reason.
    if relative.startswith("assets/"):
        return "public, max-age=31536000, immutable"
    return "no-cache"


def _resolve(target, root):
    """Map a request path to a file inside root, or None if it escapes."""
    path = urllib.parse.urlsplit(target).path
    path = urllib.parse.unquote(path)
    # normpath collapses ../ before we ever touch the filesystem; the
    # resolved-parents check below then catches symlinks pointing outward.
    path = posixpath.normpath(path)
    if path in {"/", ".", ""}:
        path = f"/{INDEX}"
    if not path.startswith("/") or path.startswith("//"):
        return None
    candidate = root / path.lstrip("/")
    try:
        resolved = candidate.resolve(strict=True)
        base = root.resolve(strict=True)
    except OSError:
        return None
    if resolved != base and base not in resolved.parents:
        return None
    return resolved if resolved.is_file() else None


def respond(request, root=None):
    """Return an HTTP Response for a non-WebSocket request, or None.

    None means "not ours": let the WebSocket handshake proceed.
    """
    root = root or WEB_ROOT
    # An upgrade request is the kernel socket, never a page fetch.
    if request.headers.get("Upgrade", "").lower() == "websocket":
        return None
    if not available(root):
        # Falling through here would hand the page request to the WebSocket
        # handshake, which answers "you cannot access a WebSocket server
        # directly with a browser" — true, and useless. Say the real thing.
        return _no_app_installed()

    method = getattr(request, "method", "GET")
    if method not in {"GET", "HEAD"}:
        return _error(405, "Method Not Allowed", allow="GET, HEAD")

    resolved = _resolve(request.path, root)
    if resolved is None:
        return _error(404, "Not Found")

    body = resolved.read_bytes()
    relative = resolved.relative_to(root.resolve()).as_posix()
    fields = {
        "Content-Type": _content_type(resolved),
        "Content-Length": str(len(body)),
        "Cache-Control": _cache_control(relative),
        # The app is local and self-contained; nothing should frame it or
        # sniff its types. index.html carries the full CSP.
        "X-Content-Type-Options": "nosniff",
        "Frame-Options": "DENY",
    }
    if resolved.suffix == ".html":
        fields["Content-Security-Policy"] = LOCAL_CSP
    return Response(200, "OK", Headers(fields), b"" if method == "HEAD" else body)


NO_APP_PAGE = """<!doctype html>
<meta charset="utf-8">
<title>Knuth — no app bundled</title>
<style>
  body { font: 16px/1.6 ui-sans-serif, system-ui, sans-serif; background: #2b2a2d;
         color: #e8e6e3; margin: 0; display: grid; place-items: center; min-height: 100vh; }
  main { max-width: 34rem; padding: 2rem; }
  code { background: #1f1e22; padding: .15rem .4rem; border-radius: 4px; }
  pre { background: #1f1e22; padding: 1rem; border-radius: 8px; overflow-x: auto; }
</style>
<main>
  <h1>The engine is running, but no app is bundled with it</h1>
  <p>Python is answering on this port — the interface is what is missing. That
  happens when Knuth is installed from a source tree whose frontend was never
  built.</p>
  <p>From a checkout:</p>
  <pre>npm install &amp;&amp; npm run build:engine</pre>
  <p>then restart the engine. Cells still run through
  <code>knuth run</code> in the meantime.</p>
</main>
"""


def _no_app_installed():
    body = NO_APP_PAGE.encode()
    return Response(503, "Service Unavailable", Headers({
        "Content-Type": "text/html; charset=utf-8",
        "Content-Length": str(len(body)),
        "Cache-Control": "no-store",
    }), body)


def _error(status, phrase, allow=None):
    body = f"{status} {phrase}\n".encode()
    fields = {
        "Content-Type": "text/plain; charset=utf-8",
        "Content-Length": str(len(body)),
        "Cache-Control": "no-store",
    }
    if allow:
        fields["Allow"] = allow
    return Response(status, phrase, Headers(fields), body)
